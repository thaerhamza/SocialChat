import 'package:flutter/material.dart';

class Upload extends StatefulWidget {
  Upload({Key key}) : super(key: key);

  @override
  _UploadState createState() => _UploadState();
}

class _UploadState extends State<Upload> {
  @override
  Widget build(BuildContext context) {
    return Container(
      child: Center(
        child: Text("Upload"),
      ),
    );
  }
}
