import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:socialchat/widgets/header.dart';
import 'package:socialchat/widgets/progress.dart';

final usersRef = Firestore.instance.collection("users");

class Timeline extends StatefulWidget {
  Timeline({Key key}) : super(key: key);

  @override
  _TimelineState createState() => _TimelineState();
}

class _TimelineState extends State<Timeline> {
  List<dynamic> users = [];

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    //createUser();
    //updateUser();
    deleteUser();
    getUsers();
    //getUsersById();
  }

  createUser() {
    usersRef
        .document("1234567")
        .setData({"name": "mohammad", "isAdmin": false, "postsCount": 1});
  }

  updateUser() async {
    final DocumentSnapshot doc = await usersRef.document("1234567").get();
    if (doc.exists) {
      doc.reference
          .updateData({"name": "johan", "isAdmin": false, "postsCount": 1});
    }
  }

  deleteUser() async {
    final DocumentSnapshot doc = await usersRef.document("1234567").get();
    if (doc.exists) {
      doc.reference.delete();
    }
  }

  getUsers() async {
    QuerySnapshot snapshot = await usersRef.getDocuments();

    setState(() {
      users = snapshot.documents;
    });
    /* snapshot.documents.forEach((DocumentSnapshot doc) {
      print(doc.data);
      print(doc.documentID);
      print(doc.exists);
    });*/
  }

  getUsersById() async {
    final String id = "yy9DGj0kijkEUy4ZPT7h";
    final DocumentSnapshot doc = await usersRef.document(id).get();
    print(doc.data);
    print(doc.documentID);
    print(doc.exists);
  }

  @override
  Widget build(BuildContext context) {
    return Container(
        child: Scaffold(
      appBar: header(context, isAppTitle: true),
      body: StreamBuilder<QuerySnapshot>(
        stream: usersRef.snapshots(),
        builder: (context, snapshot) {
          if (!snapshot.hasData) {
            return circularProgress();
          }
          List<Text> child = snapshot.data.documents
              .map((user) => Text(user["name"]))
              .toList();
          return ListView(
            children: child,
          );
        },
      ),
    ));
  }
}
